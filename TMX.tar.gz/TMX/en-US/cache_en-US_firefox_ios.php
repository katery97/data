<?php
$tmx = [
'Artificial_Intelligence/arXiv:2008.12515-test' => 'Test keyword', 
'Machine_Learning/arXiv:2008.12515-test' => 'Test keyword', 
];
