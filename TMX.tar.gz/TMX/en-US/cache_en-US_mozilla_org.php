<?php
$tmx = [
'Biomolecules/arXiv:2008.12515-test' => 'Test keyword', 
'Genomics/arXiv:2008.12515-test' => 'Test keyword', 
];
