<?php
$tmx = [
'Applications/arXiv:2008.12515-test' => 'Test keyword', 
];