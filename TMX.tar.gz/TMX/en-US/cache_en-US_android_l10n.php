<?php
$tmx = [
'Algebraic_Geometry/arXiv:2008.11912-test' => 'Test keyword',
'Algebraic_Geometry/arXiv:2008.11912-title' => 'An alternative to hypercovers',
'Algebraic_Geometry/arXiv:2008.11912-abstract' => 'I introduce a class of diagrams in a Grothendieck site called "atlases" which can be used to study hyperdescent, and show that hypersheaves take atlases to limits using an indexed "nerve" construction that produces hypercovers from atlases. Atlases have the flexibility to be at the same time more explicit and more universal than hypercovers.',
'Algebraic_Geometry/arXiv:2008.11684-test' => 'Test keyword',
'Algebraic_Geometry/arXiv:2008.11684-title' => 'Non-commutative derived moduli prestacks',
'Algebraic_Geometry/arXiv:2008.11684-abstract' => 'We introduce a formalism for derived moduli functors on differential graded associative algebras, which leads to non-commutative enhancements of derived moduli stacks and naturally gives rise to structures such as Hall algebras. Descent arguments are not available in the non-commutative context, so we establish new methods for constructing various kinds of atlases. The formalism permits the development of the theory of shifted bi-symplectic and shifted double Poisson structures in the companion paper.',
'Probability/arXiv:2008.12032-test' => 'Test keyword',
'Probability/arXiv:2008.12032-title' => 'A competitive search game with a moving target',
'Probability/arXiv:2008.12032-abstract' => 'We introduce a discrete-time search game, in which two players compete to find an object first. The object moves according to a time-varying Markov chain on finitely many states. The players know the Markov chain and the initial probability distribution of the object, but do not observe the current state of the object. The players are active in turns. The active player chooses a state, and this choice is observed by the other player. If the object is in the chosen state, this player wins and the game ends. Otherwise, the object moves according to the Markov chain and the game continues at the next period.',
'Probability/arXiv:2008.12026-test' => 'Test keyword',
'Probability/arXiv:2008.12026-title' => 'Discrepancy of stratified samples from partitions of the unit cube',
'Probability/arXiv:2008.12026-test' => 'Quantum simulation has wide applications in quantum chemistry and physics. Recently, scientists have begun exploring the use of randomized methods for accelerating quantum simulation. Among them, a simple and powerful technique, called qDRIFT, is known to generate random product formulas for which the average quantum channel approximates the ideal evolution. This work provides a comprehensive analysis of a single realization of the random product formula produced by qDRIFT. The main results prove that a typical realization of the randomized product formula approximates the ideal unitary evolution up to a small diamond-norm error. The gate complexity is independent of the number of terms in the Hamiltonian, but it depends on the system size and the sum of the interaction strengths in the Hamiltonian. Remarkably, the same random evolution starting from an arbitrary, but fixed, input state yields a much shorter circuit suitable for that input state. If the observable is also fixed, the same random evolution provides an even shorter product formula. The proofs depend on concentration inequalities for vector and matrix martingales. Numerical experiments verify the theoretical predictions.',
'Algebraic_Topology/arXiv:2008.12026-test' => 'Test keyword',
'Category_Theory/arXiv:2008.12026-test' => 'Test keyword',
'Combinatorics/arXiv:2008.12026-test' => 'Test keyword',
'Logic/arXiv:2008.12026-test' => 'Test keyword',
];
