<?php
$tmx = [
'Biomolecules/arXiv:2008.12515-test' => '測試關鍵詞', 
'Genomics/arXiv:2008.12515-test' => '測試關鍵詞', 
];
