<?php
$tmx = [
'Mathematics/Algebraic_Geometry/arXiv:2008.11912-test' => '测试关键词',
'Mathematics/Algebraic_Geometry/arXiv:2008.11912-title' => '超级封面的替代品',
'Mathematics/Algebraic_Geometry/arXiv:2008.11912-abstract' => '我在一个名为“地图集”的Grothendieck网站上介绍了一类可用于研究超下降的图表，并展示了超束利用索引“神经”结构将地图集带到极限，从而从地图集产生超覆盖。地图集比超级覆盖更灵活，同时也更明确、更通用。',
'Mathematics/Algebraic_Geometry/arXiv:2008.11684-test' => '测试关键词',
'Mathematics/Algebraic_Geometry/arXiv:2008.11684-title' => '非交换导出的模预积',
'Mathematics/Algebraic_Geometry/arXiv:2008.11684-abstract' => '摘要介绍了微分分级结合律代数上的导模函子的一种形式，它导致了导模堆的非交换增强，并自然地产生了像霍尔代数这样的结构。在非交换条件下，下降论证是不可用的，因此我们建立了构造各种地图集的新方法。伴随论文的形式允许发展位移双辛和位移双泊松结构的理论。',
'Mathematics/Probability/arXiv:2008.12032-test' => '测试关键词',
'Mathematics/Probability/arXiv:2008.12032-title' => '一个有移动目标的竞争性搜索游戏',
'Mathematics/Probability/arXiv:2008.12032-abstract' => '我们引入了一个离散时间搜索游戏，其中两个玩家竞争先找到一个物体。对象在有限状态上根据时变马尔可夫链运动。参与者知道马尔可夫链和对象的初始概率分布，但不观察对象的当前状态。玩家轮流活动。主动玩家选择一种状态，而这种选择会被其他玩家观察到。如果对象处于选择的状态，则该玩家获胜，游戏结束。否则，物体根据马尔科夫链移动，游戏在下一阶段继续进行。',
'Mathematics/Probability/arXiv:2008.12026-test' => '测试关键词',
'Mathematics/Probability/arXiv:2008.12026-title' => '分层样本的差异从单位立方体的分区',
'Mathematics/Probability/arXiv:2008.12026-test' => '量子模拟在量子化学和物理中有着广泛的应用。最近，科学家们开始探索使用随机化方法来加速量子模拟。其中，一个简单而强大的技术称为qDRIFT，已知产生随机积公式，平均量子信道近似于理想进化。这项工作提供了一个全面的分析，单一实现的随机产品公式产生的qDRIFT。主要结果证明了随机积公式的一个典型实现将理想幺正演化近似到一个小的菱形范数误差。门的复杂度与哈密顿量中的项数无关，但它依赖于系统的大小和哈密顿量中相互作用强度的总和。值得注意的是，从一个任意但固定的输入状态开始的同样的随机演化，会产生一个适合于该输入状态的更短的电路。如果观测值也是固定的，同样的随机演化会提供一个更短的乘积公式。证明依赖于向量鞅和矩阵鞅的集中不等式。数值实验验证了理论预测。',
'Mathematics/ Algebraic_Topology/arXiv:2008.12026-test' => '测试关键词',
'Mathematics/Category_Theory/arXiv:2008.12026-test' => '测试关键词',
'Mathematics/Combinatorics/arXiv:2008.12026-test' => '测试关键词',
'Mathematics/Logic/arXiv:2008.12026-test' => '测试关键词',
];
