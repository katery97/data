<?php
$tmx = [
'Economics/arXiv:2008.12515-test' => '测试关键词', 
'Computational_Finance/arXiv:2008.12515-test' => '测试关键词', 
];