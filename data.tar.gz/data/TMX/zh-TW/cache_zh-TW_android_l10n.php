<?php
$tmx = [
'Mathematics/Algebraic_Geometry/arXiv:2008.11912-test' => '測試關鍵詞',
'Mathematics/Algebraic_Geometry/arXiv:2008.11912-title' => '超級封面的替代品',
'Mathematics/Algebraic_Geometry/arXiv:2008.11912-abstract' => '我在壹個名為“地圖集”的Grothendieck網站上介紹了壹類可用於研究超下降的圖表，並展示了超束利用索引“神經”結構將地圖集帶到極限，從而從地圖集產生超覆蓋。地圖集比超級覆蓋更靈活，同時也更明確、更通用。',
'Mathematics/Algebraic_Geometry/arXiv:2008.11684-test' => '測試關鍵詞',
'Mathematics/Algebraic_Geometry/arXiv:2008.11684-title' => '非交換導出的模預積',
'Mathematics/Algebraic_Geometry/arXiv:2008.11684-abstract' => '摘要介紹了微分分級結合律代數上的導模函子的壹種形式，它導致了導模堆的非交換增強，並自然地產生了像霍爾代數這樣的結構。在非交換條件下，下降論證是不可用的，因此我們建立了構造各種地圖集的新方法。伴隨論文的形式允許發展位移雙辛和位移雙泊松結構的理論。',
'Mathematics/Probability/arXiv:2008.12032-test' => '測試關鍵詞',
'Mathematics/Probability/arXiv:2008.12032-title' => '壹個有移動目標的競爭性搜索遊戲',
'Mathematics/Probability/arXiv:2008.12032-abstract' => '我們引入了壹個離散時間搜索遊戲，其中兩個玩家競爭先找到壹個物體。對象在有限狀態上根據時變馬爾可夫鏈運動。參與者知道馬爾可夫鏈和對象的初始概率分布，但不觀察對象的當前狀態。玩家輪流活動。主動玩家選擇壹種狀態，而這種選擇會被其他玩家觀察到。如果對象處於選擇的狀態，則該玩家獲勝，遊戲結束。否則，物體根據馬爾科夫鏈移動，遊戲在下壹階段繼續進行。',
'Mathematics/Probability/arXiv:2008.12026-test' => '測試關鍵詞',
'Mathematics/Probability/arXiv:2008.12026-title' => '分層樣本的差異從單位立方體的分區',
'Mathematics/Probability/arXiv:2008.12026-test' => '量子模擬在量子化學和物理中有著廣泛的應用。最近，科學家們開始探索使用隨機化方法來加速量子模擬。其中，壹個簡單而強大的技術稱為qDRIFT，已知產生隨機積公式，平均量子信道近似於理想進化。這項工作提供了壹個全面的分析，單壹實現的隨機產品公式產生的qDRIFT。主要結果證明了隨機積公式的壹個典型實現將理想幺正演化近似到壹個小的菱形範數誤差。門的復雜度與哈密頓量中的項數無關，但它依賴於系統的大小和哈密頓量中相互作用強度的總和。值得註意的是，從壹個任意但固定的輸入狀態開始的同樣的隨機演化，會產生壹個適合於該輸入狀態的更短的電路。如果觀測值也是固定的，同樣的隨機演化會提供壹個更短的乘積公式。證明依賴於向量鞅和矩陣鞅的集中不等式。數值實驗驗證了理論預測。',
'Mathematics/ Algebraic_Topology/arXiv:2008.12026-test' => '測試關鍵詞',
'Mathematics/Category_Theory/arXiv:2008.12026-test' => '測試關鍵詞',
'Mathematics/Combinatorics/arXiv:2008.12026-test' => '測試關鍵詞',
'Mathematics/Logic/arXiv:2008.12026-test' => '測試關鍵詞',
];
