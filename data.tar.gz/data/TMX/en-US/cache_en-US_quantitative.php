<?php
$tmx = [
'Economics/arXiv:2008.12515-test' => 'Test keyword', 
'Computational_Finance/arXiv:2008.12515-test' => 'Test keyword', 
];